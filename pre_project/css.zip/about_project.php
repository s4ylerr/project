<?php
	require_once('template/header.php');
?>

		тук вече ни е страницата относно приложението
		

<?php
	require_once('template/footer.php');
?>