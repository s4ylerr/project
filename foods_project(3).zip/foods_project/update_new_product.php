<?php 
require_once('template/header.php');
$username = $_SESSION['user'];
require_once('functions.php');
require_once('includes.php');
if(!empty($_GET)) {
	$product = $_GET['uproduct'];
} else {
	$product = '';
} 	
	//retrieving product info
$q = "SELECT * FROM `products` WHERE `product` = '$product'";
$result = mysqli_query($connect, $q);
if (mysqli_num_rows($result)>0) {
	$row = mysqli_fetch_assoc($result);
}
?>
<div class="row enterr" style="background-image:url('images/lines.png')";>	
	<div class="col-xs-12 just">
		<div class="first_enterr text-center col-xs-8 col-xs-offset-2">				
			<h3>Промени информацията за продукта</h3>
			<div class="row">
				<div class="col-xs-10 col-xs-offset-1">
					<form method="post" action="update_new_product.php" class="form-horizontal">	
						<input type="hidden" name="username" value="<?php echo $username;?>">
						<input type="hidden" name="id" value="<?php echo $row['id']?>">	
						<div class="form-group">									
							<div class="col-xs-4">
								<label for="nm">Продукт</label>	
							</div>
							<div class="col-xs-8">
								<input type="text" class="form-control" name="product" id="nm" value="<?php if(isset($row['product'])) {echo $row['product']; }?>"/>
							</div>
						</div>		
						<div class="row">
							<div class="form-group">
								<div class="col-xs-8">
									<label for="cal">Kалории в 100 г продукт</label>
								</div>
								<div class="col-xs-2">
									<input type="number" class="form-control" name="cal" id="cal" value="<?php echo $row['calories'];?>"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group ">
								<div class="col-xs-8">
									<label for="gi">ГИ за 100 г продукт</label>
								</div>
								<div class="col-xs-2">
									<input type="number" class="form-control" name="gi" id="gi" value="<?php echo $row['gi'];?>"/>
								</div>
							</div>
							<tr>
					<div class="row">
						<?php 
						if (!empty($row['content_photo'])) {
							echo '<img class="img-responsive img-thumbnail" src="data:image/jpeg;base64,'.base64_encode( $row['content_photo'] ).'"/>';
						}
						?>
					</div>
						<div class="row">
								<div class="form-group ">
									<label for="des">Описание на продукта</label>
									<textarea id="des" class="form-control" name="description" value="<?php echo $row['description'];?>">
									<?php echo $row['description'];?>
									</textarea>
								</div>
							</div>
							<div class="row form-group">
								<button type="submit" name="submit" class="btn btn-primary">ЗАПИШИ</button>						
							</div>	
						</form>
						<?php 
						if (!empty($_POST)) {
							$id = $_POST['id'];
							$product = $_POST['product'];
							$cal = $_POST['cal'];
							$gi = $_POST['gi'];	
							$q_new_info = "UPDATE `products` 
							SET `product`='$product',
							`calories`=$cal,
							`gi`=$gi
							WHERE `id` = $id";
							if (mysqli_query($connect, $q_new_info)) {
								echo '<h3 class="bg-info text-info">Променихте успешно информацията за продукта!</h3>';
							} else {
								echo 'Опитайте отново!';
							}
						} 
						?>
						<table class="table">
						<tr>
								<td><a class="btn btn-primary" href="main.php"role="button">ВСИЧКИ РЕЦЕПТИ</a></td>
								<td><a class="btn btn-danger" href="delete_new_product.php?del_product=<?php echo $product?>" role="button">ИЗТРИЙ</a></td>
								<td><a class="btn btn-warning" href="display_product.php?dproduct=<?php echo $product?>" role="button">ПРЕГЛЕДАЙ</a></td>
								<td><a class="btn btn-info" href="photo_product.php?product=<?php echo $product?>" role="button">СНИМКА</a></td>
							</tr>
						</table>
						
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
	require_once('template/footer.php');