<?php 
require_once('template/header.php');
$username = $_SESSION['user'];
require_once('functions.php');
require_once('includes.php');



?>
<div class="row enterr" style="background-image:url('images/lines.png')";>	
	<div class="col-xs-12 just">
		<div class="first_enterr text-center col-xs-8 col-xs-offset-2">	
			<!-- форма за продуктите-->
			<h3>Въведете данни за продукт</h3>
			<div class="row">
				<div class="col-xs-10 col-xs-offset-1">
					<form method="post" action=""  class="form-horizontal">	
						<div class="row">
							<div class="form-group">									
								<div class="col-xs-4">
									<label>Продукт</label>	
								</div>
								<div class="col-xs-8">
									<input type="text" class="form-control" name="product" />
								</div>
							</div>
							<div class="row">
								<div class="form-group">
									<div class="col-xs-8">
										<label>Kалории в 100 г продукт</label>
									</div>
									<div class="col-xs-2">
										<input type="number" class="form-control" name="cal"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="form-group ">
									<div class="col-xs-8">
										<label>Гликемичен индекс за 100 г продукт</label>
									</div>
									<div class="col-xs-2">
										<input type="number" class="form-control" name="gi" />
									</div>
								</div>
								<div class="row">
									<div class="form-group ">
										<label>Описание на продукта</label>
										<textarea class="form-control" name="description">

										</textarea>
									</div>
								</div>
								<div class="row form-group">
									<button type="submit" name="submit" class="btn btn-primary">ЗАПИШИ</button>						
								</div>
							</form>
							<?php 

							if (isset($_POST['submit'])) {
								$product = $_POST['product'];
								$cal = $_POST['cal'];
								$gi = $_POST['gi'];	
								$description = $_POST['description'];	
								$q = "SELECT * FROM `users` WHERE `username` = '$username'";
								$result = mysqli_query($connect, $q);
								$row = mysqli_fetch_assoc($result);	
								$id_user= $row['id'];
								//echo $id_user.' '.$product." ".$cal." ".$gi.' '.$description.' '.$date;

								$q = "INSERT INTO `products`(`product`, `description`, `calories`, `gi`, `id_user`, `date_published`) 
								VALUES ('$product', '$description', $cal, $gi, $id_user, '$date')";
								 $res = mysqli_query($connect, $q);

								if ($res) {
									echo "Успешно добавихте <span class='bg-info text-info'>".$product ."</span> в базата данни!";
								} else{
									echo "Неуспешно добавяне на запис в базата данни! Моля опитайте по-късно!";
								}
							}
							?>
							
						</div>
					</div>
					<div class="row">
						<div class="col-xs-2 col-xs-offset-2">
							<a class="btn btn-danger" href="delete_new_product.php?del_product=<?php echo $product?>" role="button">ИЗТРИЙ</a>
						</div>
						<div class="col-xs-3">
							<a class="btn btn-info" href="display_product.php?dproduct=<?php echo $product?>" role="button">ПРЕГЛЕДАЙ</a>
						</div>
						<div class="col-xs-2">
							<a class="btn btn-primary" href="main.php" role="button">ВСИЧКИ РЕЦЕПТИ</a>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
	require_once('template/footer.php');