<?php 
require_once('template/header.php');
$username = $_SESSION['user'];
require_once('functions.php');
require_once('includes.php');

if (isset($_GET)) {
	$dproduct = $_GET['dproduct'];
} else {
	echo "";
}
//echo $product;
$i = 0;
$q = "SELECT * FROM `products`
JOIN `users` ON  `products`.`id_user` = `users`.`id`
WHERE `products`.`product`= '$dproduct'"; 
$res = mysqli_query($connect, $q);
$row = mysqli_fetch_assoc($res);

?>
<div class="row ">	
	<div class="col-xs-12 just">
		<div class="first_enterr text-center col-xs-8 col-xs-offset-2">	
			<h3> Информация за <?php echo $row['product'];?></h3>
			
			<table class="table ">
				<tr>
					<td>
						Калории/100 гр
					</td> 
					<td colspan="3">
						<?php echo $row['calories']; ?>
					</td>
				</tr>
				<tr>
					<td>
						ГИ/100гр
					</td> 
					<td colspan="3">
						<?php echo $row['gi']; ?>
					</td>
				</tr>
				<tr>
					<td>
						публикувана от
					</td> 
					<td colspan="3">
						<?php echo $row['username']; ?>
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<?php echo $row['date_published']; ?>
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<?php 
						if (!empty($row['content_photo'])) {
							echo '<img class="img-responsive img-thumbnail" src="data:image/jpeg;base64,'.base64_encode( $row['content_photo'] ).'"/>';
						}
						?>
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<?php echo $row['description']; ?>
					</td>
				</tr>
				<tr >
					<td><a class="btn btn-primary" href="main.php"role="button">ВСИЧКИ РЕЦЕПТИ</a></td>
					<td><a class="btn btn-danger" href="delete_new_product.php?del_product=<?php echo $dproduct?>" role="button">ИЗТРИЙ</a></td>
					<td><a class="btn btn-warning" href="update_new_product.php?uproduct=<?php echo $dproduct?>" role="button">ПРОМЕНИ</a></td>
					<td><a class="btn btn-info" href="photo_product.php?photop=<?php echo $dproduct?>" role="button">СНИМКА</a></td>
				</tr>
			</table>

		</div>
	</div>
</div>

<?php
require_once('template/footer.php');