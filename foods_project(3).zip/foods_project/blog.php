<?php
	require_once('template/header.php');
	require_once('functions/shorter_text.php');

	?>

	<div class="row">
			<div class="col-md-12 just">
				<div class="first text-center col-xs-12">
					<div class="row">
						<div class="newclas col-xs-12">						

						
						<!--                започва менюто			-->

							<ul class="nav nav-tabs">
							

								<?php

									$select_categories_article = "SELECT * FROM categories_article"; // избирам всички категории от блога

									$query = mysqli_query($connect, $select_categories_article)or die(mysqli_error()); // пускам заявката

									if (mysqli_num_rows($query) >0) { // проверявам дали има повече от 0 записа

										while ($r = mysqli_fetch_assoc($query)) { // обхождам всички записи на категориите от блога
											
											if ($_GET) {

												$get_id = $_GET['category'];

												if ($get_id == $r['id_category']) {

													echo '<li class="active" role="presentation"><a href="?category='. $r['id_category'] .'">' . $r['category'] . '</a></li>';
													
												}else{

													echo '<li role="presentation"><a href="?category='. $r['id_category'] .'">' . $r['category'] . '</a></li>';
												}
												

											}else{

													echo '<li role="presentation"><a href="?category='. $r['id_category'] .'">' . $r['category'] . '</a></li>';

												}
											

										}

									}

								?>

							</ul>
						<!--                край на  менюто			-->


						</div>
					</div>
				</div>
			</div>
		</div>
		
<div class="row">
			<div class="col-md-9">
<?php

if ($_GET) {
if (!isset($_GET['article'])){ 

	$category = $_GET['category'];

	$query_categories = "SELECT * FROM articles WHERE id_category = '$category' AND date_deleteed IS NULL";

	$sql_article = mysqli_query($connect, $query_categories)or die(mysqli_error());

	if (mysqli_num_rows($sql_article) > 0) {
		while ($r = mysqli_fetch_assoc($sql_article)) {
			
			
			?>
			<div class="categories_article">
			
			        <h3 class="h3"><a href="?category=<?php echo $_GET['category']; ?>&article=<?php echo $r['id_article']; ?>"><?php  echo $r['title_article']; ?></a></h3>
			       <div><?php echo shorter($r['text_article'], 150); ?></div>
			       <a type="button" class="btn btn-primary btn-xs" class="btn btn-primary btn-lg active" role="button" href="?category=<?php echo $_GET['category']; ?>&article=<?php echo $r['id_article']; ?>">прочети още ...</a>
			</div>


			<?php

		}
	}else{

		echo "<div class='msg_danger bg-danger'>Вижте другите категории</div>";

	}
}
	//echo '<div style="clear: both;"></div>';


	// опит за изкарване на статия
	if (isset($_GET['article'])){

		$article_id = $_GET['article'];

		$select_one_article = "SELECT *, users.id as userid FROM articles 
		LEFT JOIN users ON articles.id_user = users.id
		WHERE id_article = '$article_id'";

		$q = mysqli_query($connect, $select_one_article)or die(mysqli_error());
		$r = mysqli_fetch_assoc($q);

		echo '<h3>' . $r['title_article'] . '</h3>';
		echo '<div class="article">';
		echo '<span class="glyphicon glyphicon-calendar"> '. $r['date_article'] .' </span> ';
		echo '<span class="glyphicon glyphicon-user"><a href="user.php?user='. $r['userid'] .'">'. $r['username'] .'</a></span> ';

		echo '</div>';
		echo '<div class="article-class"> ' . $r['text_article'] . ' </div>';
	}
	}else{

	$select_all_articles = "SELECT * FROM articles WHERE date_deleteed IS NULL"; // избирам всички статии, когато не е избрана определена категория

	$query_articles = mysqli_query($connect, $select_all_articles)or die(mysqli_error());
	if (mysqli_num_rows($query_articles)>0) {
		while ($r = mysqli_fetch_assoc($query_articles)) {
			?>

			<div class="categories_article">
			
			        <h3 class="h3"><a href="?category=<?php echo $_GET['category']; ?>&article=<?php echo $r['id_article']; ?>"><?php  echo $r['title_article']; ?></a></h3>
			       <div><?php echo shorter($r['text_article'], 150); ?></div>
			       <a type="button" class="btn btn-primary btn-xs" class="btn btn-primary btn-lg active" role="button" href="?category=<?php echo $_GET['category']; ?>&article=<?php echo $r['id_article']; ?>">прочети още ...</a>
			</div>

			<?php
		}
	}



}
?>

</div>
<div class="col-md-3">

<?php

	$sel_res_last = "SELECT * FROM recipes WHERE size_photo > 0 AND date_deleted IS NULL ORDER BY id DESC LIMIT 3";
	$q = mysqli_query($connect, $sel_res_last)or die(mysqli_error());
	if (mysqli_num_rows($q) >0) {
		while ($r = mysqli_fetch_assoc($q)) {
			?>

				<a class="rp" href="recipies.php?recipie=<?php echo $r['id_food_type']; ?>&view=<?php echo $r['id']; ?>">
		    			<div class="rowps">
						    <table>
						    	<tr>
						    		<td><h4><?php echo shorter($r['name'], 40); ?></h4></td>
						    	</tr>
						    	<tr>
							    	<td>
							    	<div class="hidps">
							    	<?php
							    	if ($r['content_photo']) {
							    		
							    	echo '<img height="250" src="data:image/jpeg;base64,'.base64_encode( $r['content_photo'] ).'"/> ';

							    }else{ 
							    	?>
							    		<img width="250" src="images/default-placeholder.png" />	
							    	<?php
							    	}
							    	?>
							    	</div>
							    	</td>
						    	</tr>
						    	<tr>
						    		<td><h6><b><?php echo $r['date_published']; ?></b></h6></td>
						    	</tr>
						    </table>
					    </div>
					</a>


			<?php
		}
	}

?>

</div>
</div>

<?PHP
	require_once('template/footer.php');
?>


									  
									