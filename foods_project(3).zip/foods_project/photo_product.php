<?php 
require_once('template/header.php');
$username = $_SESSION['user'];
require_once('functions.php');
require_once('includes.php');
if(!empty($_GET)) {
	$product = $_GET['photop'];
} else {
	$product = '';
} 	
//retrieving product info
$q = "SELECT * FROM `products` WHERE `product` = '$product'";
$result = mysqli_query($connect, $q);
if (mysqli_num_rows($result)>0) {
	$row = mysqli_fetch_assoc($result);
}
?>
<div class="row enterr" style="background-image:url('images/lines.png')";>	
	<div class="col-xs-12 just">
		<div class="first_enterr text-center col-xs-8 col-xs-offset-2">	
			
			<h3>Изберете снимка</h3>
			<div class="row">
				<div class="col-xs-10 col-xs-offset-1">
					<form method="post" action="photo_product.php" enctype="multipart/form-data"  class="form-horizontal">
						<input type="hidden" name="id" value="<?php  if (isset ($row['id'])){ echo $row['id']; }?>">
						<input type="hidden" name="product" value="<?php  if (isset ($product)){ echo $product; }?>">
						<div class="row form-group">
							<div class="new_ph col-xs-6 col-xs-offset-3">
								<input type="file" name="photo" >
							</div>
						</div>
						<div class="row form-group">
							<div class="col-xs-6 col-xs-offset-3">
								<button type="submit" name="submit" class="btn btn-primary">ЗАПИШИ</button>	
							</div>
						</div>						
					</form>
					<?php 
		/*$q_new_info = "UPDATE `products` 
						SET `product`='$product',
						`calories`=$cal,
						`gi`=$gi
						WHERE `id` = $id";*/
						if (isset($_POST['submit'])) {
							$id = $_POST['id'];
							$product = $_POST['product'];
							if(!empty($_FILES))		{	
								$file_name = $_FILES['photo']['name'];
								$tmp_name = $_FILES['photo']['tmp_name'];
								$file_size = $_FILES['photo']['size'];
								$file_type = $_FILES['photo']['type'];
								$content = addslashes(file_get_contents($tmp_name));
//insering picture into the
								$q = "UPDATE `products` 
								SET `content_photo`='$content',
								`name_photo`='$file_name',
								`type_photo`='$file_type',
								`size_photo`='$file_size'
								WHERE `id` = $id";
								if (mysqli_query($connect, $q)) {
									
									$q = "SELECT `content_photo` FROM `products` WHERE id = $id";
									$result = mysqli_query($connect, $q);
									$row = mysqli_fetch_assoc($result);
									echo '<img class="img-responsive img-thumbnail" src="data:image/jpeg;base64,'.base64_encode( $row['content_photo'] ).'"/>';
								} else {
									echo "Опитайте отново!";
								}
							}
						}
						?>
						<table class="table">
							<tr>
								<td><a class="btn btn-primary" href="main.php"role="button">ВСИЧКИ РЕЦЕПТИ</a></td>
								<td><a class="btn btn-warning" href="display_product.php?dproduct=<?php echo $product?>" role="button">ПРЕГЛЕДАЙ ПРОДУКТ</a></td>
								<td><a class="btn btn-info" href="update_photo_product.php?id=<?php echo $id;?>" role="button">ПРОМЕНИ СНИМКА</a></td>
							</tr>
						</table>						
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
	require_once('template/footer.php');