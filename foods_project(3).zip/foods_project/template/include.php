<?php
if ($_GET) {
		if (isset($_GET['article'])) {
			
			$query = "SELECT `articles`.`title_article` as art, `categories_article`.`category` as cat FROM 
			`articles` JOIN `categories_article` ON `articles`.`id_category`=`categories_article`.`id_category` 
			WHERE `articles`.`id_article` = '$_GET[article]'";
			
			$result = mysqli_fetch_assoc(queries($connect, $query));

			echo $result['art'] . ' - ' . $result['cat'] . ' - ' . $fetch_row['name_menu'];			

		}elseif(isset($_GET['category'])){			


			$query = "SELECT category FROM categories_article WHERE id_category = '$_GET[category]'";
			
			$result = mysqli_fetch_assoc(queries($connect, $query));
			echo $result['category'] . ' - ' . $fetch_row['name_menu'];

		}elseif (isset($_GET['view'])) {
			$query = "SELECT name FROM recipes WHERE id = '$_GET[view]'";
			
			$result = mysqli_fetch_assoc(queries($connect, $query));
			echo $result['name'];
		}elseif(isset($_GET['recipie'])){
			$query = "SELECT food_type FROM food_types WHERE id_food = '$_GET[recipie]'";
			
			$result = mysqli_fetch_assoc(queries($connect, $query));
			echo $result['food_type'];
		}elseif ($_GET['product']) {
			$select_product = "SELECT product FROM products WHERE id = '$_GET[product]'";
			$q = mysqli_query($connect, $select_product)or die(mysqli_error());
			$fr = mysqli_fetch_assoc($q);

			echo "$fr[product] - калории и гликемичен индекс (ГИ)";
		}elseif ($_GET['user']) {
			//echo $_GET['user'];
			
			$select_username = "SELECT username FROM users WHERE id = '$_GET[user]'";
			$q = mysqli_query($connect, $select_username)or die(mysqli_error());
			$fr = mysqli_fetch_assoc($q);
			echo $fr['username'];
			
		}elseif($_GET['displayr']){

			$select_displayr = "SELECT name FROM recipes WHERE id = '$_GET[displayr]'";
			$q = mysqli_query($connect, $select_displayr)or die(mysqli_error());
			$fr = mysqli_fetch_assoc($q);
			echo 'Преглеждане на ' . $fr['name'];

		}
		elseif($_GET['updaterd']){

			$select_updaterd = "SELECT name FROM recipes WHERE id = '$_GET[updaterd]'";
			$q = mysqli_query($connect, $select_updaterd)or die(mysqli_error());
			$fr = mysqli_fetch_assoc($q);
			echo 'Редактиране на ' . $fr['name'];

		}elseif($_GET['dproduct']){

			
			echo 'Преглед на ' . $_GET['dproduct'];

		}elseif ($_GET['del_product']) {
			echo 'Изтриване на ' . $_GET['del_product'];
		}
		elseif ($_GET['uproduct']) {
			echo 'Редактиране на ' . $_GET['uproduct'];
		}
		elseif ($_GET['id_rec']) {
			echo 'Редактиране на снимка';
		}
		elseif ($_GET['search']) {
			echo 'Резултати за ' . $_GET['search'];
		}
	}else{

		if ($fetch_row_other['name']){

			echo $fetch_row_other['name'];

		}elseif ($fetch_row['name_menu']) {

			echo $fetch_row['name_menu'];

		}elseif($filename == "foods_project" || $filename == "recepti"){

						echo "Начало";


		}elseif($_SESSION){

			echo $_SESSION['user'];

		}
		

	}