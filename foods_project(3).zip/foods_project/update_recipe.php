<?php 
//enters recipe name and number of products	
	//temporaliry!
require_once('template/header.php');
$username = $_SESSION['user'];
require_once('functions.php');
require_once('includes.php');
if (!empty($_GET)) {
	$id_rec = $_GET['id_rec'];
	$num = $_GET['num'];
	//данните, вече въведени за рецептата и за евентуална промяна
	$q_rec = "SELECT * FROM `recipes` WHERE `id` = $id_rec";
	$res_rec = mysqli_query($connect, $q_rec);
	$row_rec = mysqli_fetch_assoc($res_rec);
} else {
	$id_rec = "";
	$num = "";
}
?>
<div class="row enterr" style="background-image:url('images/lines.png')";>	
	<!--Recipe name-->
	<div class="first_enterr text-center  col-xs-8 col-xs-offset-2">
		<div class="row r_title">
			<div class="col-xs-8 col-xs-offset-2">
				<h2 >Промени информацията за Вашата рецепта</h2>
			</div>
		</div>
		<div class="row form">
			<div class="col-xs-10 col-xs-offset-1">
				<form method="post" action="update_recipe.php"  class="rd form-horizontal">
					<div class="row form-group">	
						<label for="name">Заглавие на Вашата рецепта</label>	
						<input type="text" class="form-control" name="name" id="name" value="<?php if(isset ($row_rec)) {echo $row_rec['name']; } else {echo ""; }?>">
					</div>

					<div class="form-group">
						<div class="row">
							<div class="col-xs-6">					
								<?php 


								$q_f = "SELECT * FROM `food_types` ORDER BY `food_type`";
								echo "<p><label for='f_t'>Тип ястие</label>";
								echo "</div>
								<div class='col-xs-6'>";
									echo "<select name='id_food' id='f_t'>";
									$result_f = mysqli_query($connect, $q_f);
									if (mysqli_num_rows($result_f)>0) {
										while ($row_f = mysqli_fetch_assoc($result_f)) {
											$food_type = $row_f['food_type'];
											$id_food = $row_f['id_food'];				

											echo "<option value='$id_food'";
											if (!empty($row_rec)) {
												if ($row_rec['id_food_type'] == $id_food) {
													echo " selected";
												}
											}
											echo ">".$food_type."</option>";
										}
									}
									echo "</select></div>";


									?>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-xs-9">
									<label for="num">Брой на продуктите, участващи в рецептата</label>
								</div>
								<div class="col-xs-2">
									<input type="number" class="form-control" name="number" value="<?php echo $num; ?>">		
								</div>
							</div>
						</div>
						<input type="hidden" name="id_user" value="<?php echo $row_rec['user_id']; ?>">
						<input type="hidden" name="id_rec" value="<?php echo $id_rec; ?>">
						<div class="row">
							<div class="col-xs-6 col-xs-offset-3">
								<button type="submit" name="submit" class="btn btn-primary">ЗАПИШИ</button>	
							</div>
						</div>

					</form>


					<?php 
					if (isset($_POST['submit'])) {
						$num = $_POST['number'];
						$name = $_POST['name'];
						$date = date('Y-m-d');
						$id_food = $_POST['id_food'];
			//id user
						$id = $_POST['id_user'];
						$id_rec = $_POST['id_rec'];
		//updating recipe into database				
						$q = "UPDATE `recipes` SET `name`= '$name', `id_food_type`= $id_food,`date_published`= '$date'
						WHERE `id`= $id_rec";
						
							if (mysqli_query($connect, $q)) {	
							echo "<div class'row'><div clas='col-xs-12'><h3 class='bg-info text-info'><em>".$name."</em></h3></div></div>";
											echo "<div class'row'><div clas='col-xs-12'>Рецептата съдържа <strong>".$num." продукта</strong></div></div>";				
								

						echo "<div class='row'>
						<div class='col-xs-4 col-xs-offset-2'>
							<a class='btn btn-info' href='enter_recipe_details.php?id_rec=$id_rec&num=$num' role='button'>ВЪВЕДИ ДЕТАЙЛИ ЗА РЕЦЕПТАТА</a>";
						} 	

					} 
					echo "</div>";

					?>
					<div class="col-xs-2 col-xs-offset-2">
						<a class="btn btn-danger" href="delete_recipe.php?id_rec=<?php echo $id_rec?>" role="button">ИЗТРИЙ</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
	require_once('template/footer.php');