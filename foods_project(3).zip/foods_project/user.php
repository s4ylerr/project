<?php 
require_once('template/header.php');
require_once('functions/shorter_text.php');

?>

<div class="row">

<div class="left col-md-3">
	<?php 

	$select_info = "SELECT *, COUNT(recipes.user_id) as cr FROM users 
	LEFT JOIN user_info ON users.id = user_info.id_user 
	LEFT JOIN recipes ON users.id = recipes.user_id
	WHERE users.id = '$_GET[user]'";

	$qinfo = mysqli_query($connect, $select_info)or die(mysqli_error());

	$rinfo = mysqli_fetch_assoc($qinfo);

	?>
	<table class="table">
		<tr>
			<?php
				if ($rinfo['profile_picture']) {
					
				
			?>
				<td rowspan="3"><?php echo '<img width="100" src="data:image/jpeg;base64,'.base64_encode( $rinfo['profile_picture'] ).'"/> '; ?></td>
				
			<?php
				}else{
					?>

					<td rowspan="3"><img width="100" src="images/profile.jpg"></td>

					<?php
				}
			?>
				
			
			<tr>
				<td><b><?php echo $rinfo['username']; ?></b></td>
			</tr>
			<tr>
			
				<td colspan="2">
					<?php echo $rinfo['info_user']; ?>
				</td>
			</tr>
			<tr>
			<td colspan="2">
					Потребител от: 
				</td>
				<td colspan="2">
					<?php echo $rinfo['date']; ?>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					Рецепти <span class="badge active"><?php echo $rinfo['cr']; ?></span><br />
					<?php
						$count_article = "SELECT COUNT(*) as c FROM articles WHERE id_user = '$_GET[user]' AND date_deleteed IS NULL";
						$query_count = mysqli_query($connect, $count_article)or die(mysqli_error());
						$r_count = mysqli_fetch_assoc($query_count);

						// products count

						$count_products = "SELECT COUNT(*) as cp FROM products WHERE id_user = '$_GET[user]' AND date_deleted IS NULL";
						$query_countp = mysqli_query($connect, $count_products)or die(mysqli_error());
						$r_countp = mysqli_fetch_assoc($query_countp);
					?>
					Блог пост <span class="badge"><?php echo $r_count['c']; ?></span><br />
					Продукти <span class="badge"><?php echo $r_countp['cp']; ?></span>
				</td>
			</tr>
		</tr>
	</table>

</div>
<div class="left col-md-8 col-md-offset-1">
<h3 class="h3">Продукти</h3>
<?php
$product_user = "SELECT * FROM products WHERE id_user = '$_GET[user]' AND date_deleted IS NULL";
$qup = mysqli_query($connect, $product_user)or die(mysqli_error());
if (mysqli_num_rows($qup) > 0) {
	while ($r = mysqli_fetch_assoc($qup)) {
	
	if ($r['content_photo']) {

		echo '<a href="products.php?product='. $r['id'] .'"><img title="'. $r['product'] .'" width="100" src="data:image/jpeg;base64,'.base64_encode( $r['content_photo'] ).'"/></a> ';
	}else{
		echo '<a href="products.php?product='. $r['id'] .'">'. $r['product'] .'</a> ';	
	}		

	}
}
?>
  <div class="clear"></div>
</div>
<div class="row">
<div class="left col-md-9">
	<h3 class="h3">Рецепти</h3>

	<?php 

	$select_all_user_recipe = "SELECT id, name, content_photo, date_published, id_food_type FROM recipes WHERE user_id = '$_GET[user]' AND date_deleted IS NULL";

	$qsaur = mysqli_query($connect, $select_all_user_recipe)or die(mysqli_error());

	if (mysqli_num_rows($qsaur) > 0) {
		
		while ($result = mysqli_fetch_assoc($qsaur)) {
			
		

	?>

	<a class="rp" href="recipies.php?recipie=<?php echo $result['id_food_type']; ?>&view=<?php echo $result['id']; ?>">
		<div class="rowps">
		    <table>
		    	<tr>
		    		<td><h4><?php echo shorter($result['name'], 35); ?></h4></td>
		    	</tr>
		    	<tr>
			    	<td>
			    	<div class="hidps">
			    	<?php
			    	if ($result['content_photo']) {
			    		
			    	echo '<img height="250" src="data:image/jpeg;base64,'.base64_encode( $result['content_photo'] ).'"/> ';

			    }else{ 
			    	?>
			    		<img width="250" src="images/default-placeholder.png" />	
			    	<?php
			    	}
			    	?>
			    	</div>
			    	</td>
		    	</tr>
		    	<tr>
		    		<td><h6><b><?php echo $result['date_published']; ?></b></h6></td>
		    	</tr>
		    </table>
	    </div>
	</a>

	<?php 

		}

	}

	?>
  <div class="clear"></div>
</div>
<div class="left col-md-3">
	<h3 class="h3">Блог постове</h3>

<?php 

	$select_all_user_articles = "SELECT * FROM articles WHERE id_user = '$_GET[user]' AND date_deleteed IS NULL";

	$qsaua = mysqli_query($connect, $select_all_user_articles)or die(mysqli_error());

	if (mysqli_num_rows($qsaua) > 0) {
		
		while ($res = mysqli_fetch_assoc($qsaua)) {
		?>

			<div style="width: 250px; border-bottom: 1px solid #ccc;" class="categories_article">
		       <h3 class="h3"><a href="blog.php?category=<?php echo $res['id_category']; ?>&article=<?php echo $res['id_article']; ?>"><?php  echo $res['title_article']; ?></a></h3>
		       <div style="width: 250px;"><?php echo shorter($res['text_article'], 150); ?></div>
		       <a type="button" class="btn btn-primary btn-xs" class="btn btn-primary btn-lg active" role="button" href="blog.php?category=<?php echo $res['id_category']; ?>&article=<?php echo $res['id_article']; ?>">прочети още ...</a>
			</div>

		<?php
		}

	}

?>

</div>
</div>

<?php

require_once('template/footer.php');