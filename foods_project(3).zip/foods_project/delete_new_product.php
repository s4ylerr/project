<?php 
require_once('template/header.php');
require_once('functions.php');
require_once('includes.php');

?>
<div class="row enterr" style="background-image:url('images/Colorful.jpg')";>	
	<div class="col-xs-12 just">
		<div class="first_enterr text-center col-xs-8 col-xs-offset-2">
			<form method="post" action="" class="form-xorizontal">
				
				<div class="form-group">
					<label>Наистина ли искате да изтриете продукта?</label><br />
					<button type="submit" name="submit" class="btn btn-danger">ИЗТРИЙ</button>					
				</div>				
			</form>
			<?php
			if (isset($_POST['submit'])) {
				$delete_product = $_GET['del_product'];
				$q = "	UPDATE `products` 
				SET `date_deleted` = '$date' 
				WHERE `product` = '$delete_product'";
				
				if(mysqli_query($connect, $q)){
					echo '<div class="row deleted text-center">
					<div class="col-xs-6 col-xs-offset-3">
						<p class="bg-info text-info">Изтрихте продукта!</p>
					</div>
					<div class="col-xs-6 col-xs-offset-3">
						<a  class="btn btn-info active" role="button" href="main.php">ВСИЧКИ РЕЦЕПТИ</a>
					</div>
				</div>';

			}
		}
		?>
		<div class="row">
			<a href="enter_new_product.php" class="btn btn-primary active" role="button">
				ДОБАВИ ПРОДУКТ
			</a>
		</div>					



	</div>
</div>
</div>

<?php
require_once('template/footer.php');