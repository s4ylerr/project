<?php
function set_title($title){
	echo $title;
}
?>